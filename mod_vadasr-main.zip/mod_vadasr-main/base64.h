
#ifndef base64_h
#define base64_h

#include <stdio.h>

void base64_encode_block(char *inData, int inlen, char *outData, int *outlen);


#endif /* base64_h */
